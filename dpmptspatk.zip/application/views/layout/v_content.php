<?php
if ($konten) {
    $this->load->view($konten);
}
