<?php
// Pemanggilan proteksi mencegah search URL
// $this->lib_login->protection_url();

// Pemanggilan template dan diurutkan
require_once('v_home_header.php');
require_once('v_home_navbar.php');
require_once('v_content.php');
require_once('v_home_footer.php');
